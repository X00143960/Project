
package models.shoes;


import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;






  
@Entity

public class Colour extends Model {

    @Id
    private Long id;
    @Constraints.Required
    private String colourOfShoe;

    @ManyToMany(cascade = CascadeType.ALL)
    private List<Footwear> footwear;




public Colour(){

}

public static List<Colour> findAll() {
    return Colour.find.query().where().orderBy("id asc").findList();
}

    public Colour(Long id, String colourOfShoe, List<Footwear> footwear) {
        this.id = id;
        this.colourOfShoe = colourOfShoe;
        this.footwear = footwear;
       
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getColourOfShoe() {
        return colourOfShoe;
    }

    public void setColourOfShoe(String colourOfShoe) {
        this.colourOfShoe = colourOfShoe;
    }

 

    public void setFootwear( List<Footwear>footwear){
        this.footwear = footwear;
    }
    public List<Footwear> getFootwear(){
        return footwear;
    }
   

    public static Finder<Long, Colour> find = new Finder<>(Colour.class);


  





    public static Map<String,String> options() {
        LinkedHashMap<String,String> options = new LinkedHashMap<>();



        for(Colour c: Colour.findAll()) {
            options.put(Long.toString(c.getId()), c.getColourOfShoe());

        }
        return options;
    }
    
}

