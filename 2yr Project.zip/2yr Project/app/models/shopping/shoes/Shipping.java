package models.shoes;

import models.shopping.*;

import java.util.*;
import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Id;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

import java.util.Date;

import models.shoes.*;
import models.users.*;
import java.text.*;
import play.data.format.*;
@Entity
public class Shipping extends Model {
    @Id
private Long id;
@Constraints.Required
    private double shippingFee;
  private String telephoneNum;

   
    private String shippAddress;
private String cName;
private List<Shipping> ship;
    @OneToOne
    private ShopOrder shopOrder;
    public Shipping (){

    }
    public Shipping(double shippingFee,  String shippAddress, Long id, String cName, String telephoneNum) {

        this.shippingFee = shippingFee;
        this.telephoneNum = telephoneNum;
        this.shippAddress = shippAddress;
        this.id = id;
        this.cName = cName;
    }

    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");


    public void setShip( List<Shipping>ship){
        this.ship = ship;
    }
    public List<Shipping> getShip(){
        return ship;
    }

    public String getTelephoneNum(){
        return telephoneNum;
    }

    public void setTelephoneNum(String telephoneNum){
       this.telephoneNum = telephoneNum;
    }


    public double getShippingFee() {
        return shippingFee;
    }

    public void setShippingFee(double shippingFee) {
        this.shippingFee = shippingFee;
    }


    public String getShippAddress() {
        return shippAddress;
    }

    public void setShippAddress(String shippAddress) {
        this.shippAddress = shippAddress;
    }
    
    
    public static Finder<Long,Shipping> find = new Finder<Long,Shipping>(Shipping.class);


    public static List<Shipping> findAll() {
        return Shipping.find.all();
    }

    public ShopOrder getShopOrder() {
        return shopOrder;
    }

    public void setShopOrder(ShopOrder shopOrder) {
        this.shopOrder = shopOrder;
    }

    public Long getId() {

        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getCName() {
        return cName;
    }

    public void setCName(String cName) {
        this.cName = cName;
    }
    public static Map<String,String> options() {
        LinkedHashMap<String,String> options = new LinkedHashMap<>();



        for(Shipping s: Shipping.findAll()) {
            options.put(Long.toString(s.getId()), Double.toString(s.getShippingFee() ));

        }
        return options;
    }
}