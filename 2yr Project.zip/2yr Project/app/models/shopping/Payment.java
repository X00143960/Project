
package models.shopping;

import java.util.*;
import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Id;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

import java.util.Date;

import models.shoes.*;
import models.users.*;
import java.text.*;

import java.util.Calendar;
@Entity
public class Payment  extends Model{
    @Id
    private Long id;
    private String cName;
    private String creditCardNum;
    private String ccv;
    @Temporal(TemporalType.DATE)
    private Date expiryDate;
  
    @ManyToMany(cascade = CascadeType.ALL,mappedBy="payment")
    public List<ShopOrder> shopOrder;
 
    public Payment() {
      
    }

    public Payment(String cName, String creditCardNum, String ccv, Date expiryDate) {
        this.cName = cName;
        this.creditCardNum = creditCardNum;
        this.ccv = ccv;
        this.expiryDate = expiryDate;
     
    }
    @ManyToMany(cascade = CascadeType.ALL)
    private List<Footwear> footwear;

   
  public void setFootwear( List<Footwear>footwear){
        this.footwear = footwear;
    }
    public List<Footwear> getFootwear(){
        return footwear;
    }
    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }
    // public static Finder<Long,Payment> find = new Finder<Long,Payment>(Payment.class);
    
    public static final List<Payment> findAll() { 
        
        return Payment.find.all();
}   
    public List<Long> getshopSelect(){
        return shopSelect;
    }
    public void setShopSelect(List<Long> shopSelect){
        this.shopSelect = shopSelect;
    }
    public String getCreditCardNum() {
        return creditCardNum;
    }
    private List<Long> shopSelect = new ArrayList<Long>();
    public void setCreditCardNum(String creditCardNum) {
        this.creditCardNum = creditCardNum;
    }

    public String getCcv() {
        return ccv;
    }

    public void setCcv(String ccv) {
        this.ccv = ccv;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    
    public String getexpiryDateString() {
        if(expiryDate == null) {
            return "No Date Availible";
        }
        String s = new SimpleDateFormat("dd-MMM-yyyy").format(expiryDate.getTime());
        return s;
    }


    public static Finder<Long,Payment> find = new Finder<Long,Payment>(Payment.class);

    public static Map<String, String> options() {
        LinkedHashMap<String, String> options = new LinkedHashMap();

        for (Payment p: Payment.findAll()) {
            options.put(p.getId().toString(), p.getCreditCardNum());
        }
        
        return options;
    } public List <Payment>getPayment(){
    
        return payment;
        
        }
         
public List<String> getPaymentNames(){
    
    List<String> payment = new ArrayList<>();
    
    if(getPayment().size() >0){
    
    for(int i = 0; i < getPayment().size(); i++){

    payment.add(getPayment().get(i).getCreditCardNum());
}

} else {

payment.add("no payments to display at moment");

}

return payment;

} 
private List<Payment> payment;
public static boolean checkNum(String ccNumber)
{
        int sum = 0;
        boolean alternate = false;
        for (int i = ccNumber.length() - 1; i >= 0; i--)
        {
                int n = Integer.parseInt(ccNumber.substring(i, i + 1));
                if (alternate)
                {
                        n *= 2;
                        if (n > 9)
                        {
                                n = (n % 10) + 1;
                        }
                }
                sum += n;
                alternate = !alternate;
        }
        return (sum % 10 == 0);
}
}


