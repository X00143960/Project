# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table basket (
  id                            bigint auto_increment not null,
  customer_email                varchar(255),
  constraint uq_basket_customer_email unique (customer_email),
  constraint pk_basket primary key (id)
);

create table category (
  id                            bigint auto_increment not null,
  name                          varchar(255),
  constraint pk_category primary key (id)
);

create table category_footwear (
  category_id                   bigint not null,
  footwear_id                   bigint not null,
  constraint pk_category_footwear primary key (category_id,footwear_id)
);

create table colour (
  id                            bigint auto_increment not null,
  colour_of_shoe                varchar(255),
  constraint pk_colour primary key (id)
);

create table colour_footwear (
  colour_id                     bigint not null,
  footwear_id                   bigint not null,
  constraint pk_colour_footwear primary key (colour_id,footwear_id)
);

create table fav (
  id                            bigint auto_increment not null,
  customer_email                varchar(255),
  constraint uq_fav_customer_email unique (customer_email),
  constraint pk_fav primary key (id)
);

create table fit (
  id                            bigint auto_increment not null,
  fit_of_shoe                   varchar(255),
  constraint pk_fit primary key (id)
);

create table fit_footwear (
  fit_id                        bigint not null,
  footwear_id                   bigint not null,
  constraint pk_fit_footwear primary key (fit_id,footwear_id)
);

create table footwear (
  id                            bigint auto_increment not null,
  name                          varchar(255),
  description                   varchar(255),
  stock                         integer not null,
  price                         double not null,
  constraint pk_footwear primary key (id)
);

create table gender (
  id                            bigint auto_increment not null,
  gender_v                      varchar(255),
  constraint pk_gender primary key (id)
);

create table gender_footwear (
  gender_id                     bigint not null,
  footwear_id                   bigint not null,
  constraint pk_gender_footwear primary key (gender_id,footwear_id)
);

create table order_item (
  id                            bigint auto_increment not null,
  order_id                      bigint,
  basket_id                     bigint,
  fav_id                        bigint,
  footwear_id                   bigint,
  quantity                      integer not null,
  price                         double not null,
  constraint pk_order_item primary key (id)
);

create table payment (
  id                            bigint auto_increment not null,
  c_name                        varchar(255),
  credit_card_num               varchar(255),
  ccv                           varchar(255),
  expiry_date                   date,
  constraint pk_payment primary key (id)
);

create table payment_footwear (
  payment_id                    bigint not null,
  footwear_id                   bigint not null,
  constraint pk_payment_footwear primary key (payment_id,footwear_id)
);

create table shipping (
  id                            bigint auto_increment not null,
  shipping_fee                  double not null,
  telephone_num                 varchar(255),
  shipp_address                 varchar(255),
  c_name                        varchar(255),
  shop_order_id                 bigint,
  constraint uq_shipping_shop_order_id unique (shop_order_id),
  constraint pk_shipping primary key (id)
);

create table shop_order (
  id                            bigint auto_increment not null,
  order_date                    timestamp,
  customer_email                varchar(255),
  supervisor_email              varchar(255),
  constraint pk_shop_order primary key (id)
);

create table shop_order_payment (
  shop_order_id                 bigint not null,
  payment_id                    bigint not null,
  constraint pk_shop_order_payment primary key (shop_order_id,payment_id)
);

create table size (
  id                            bigint auto_increment not null,
  size_of_shoe                  double,
  constraint pk_size primary key (id)
);

create table size_footwear (
  size_id                       bigint not null,
  footwear_id                   bigint not null,
  constraint pk_size_footwear primary key (size_id,footwear_id)
);

create table true_fit (
  id                            bigint auto_increment not null,
  size                          double not null,
  fit                           varchar(255),
  new_shoe                      varchar(255),
  old_shoe                      varchar(255),
  constraint pk_true_fit primary key (id)
);

create table true_fit_footwear (
  true_fit_id                   bigint not null,
  footwear_id                   bigint not null,
  constraint pk_true_fit_footwear primary key (true_fit_id,footwear_id)
);

create table user (
  role                          varchar(255),
  email                         varchar(255) not null,
  name                          varchar(255),
  password                      varchar(255),
  password_hash                 varchar(255),
  num_returns                   integer not null,
  street                        varchar(255),
  county                        varchar(255),
  post_code                     varchar(255),
  credit_card                   varchar(255),
  contact_num                   varchar(255),
  dob                           date,
  constraint pk_user primary key (email)
);

alter table basket add constraint fk_basket_customer_email foreign key (customer_email) references user (email) on delete restrict on update restrict;

alter table category_footwear add constraint fk_category_footwear_category foreign key (category_id) references category (id) on delete restrict on update restrict;
create index ix_category_footwear_category on category_footwear (category_id);

alter table category_footwear add constraint fk_category_footwear_footwear foreign key (footwear_id) references footwear (id) on delete restrict on update restrict;
create index ix_category_footwear_footwear on category_footwear (footwear_id);

alter table colour_footwear add constraint fk_colour_footwear_colour foreign key (colour_id) references colour (id) on delete restrict on update restrict;
create index ix_colour_footwear_colour on colour_footwear (colour_id);

alter table colour_footwear add constraint fk_colour_footwear_footwear foreign key (footwear_id) references footwear (id) on delete restrict on update restrict;
create index ix_colour_footwear_footwear on colour_footwear (footwear_id);

alter table fav add constraint fk_fav_customer_email foreign key (customer_email) references user (email) on delete restrict on update restrict;

alter table fit_footwear add constraint fk_fit_footwear_fit foreign key (fit_id) references fit (id) on delete restrict on update restrict;
create index ix_fit_footwear_fit on fit_footwear (fit_id);

alter table fit_footwear add constraint fk_fit_footwear_footwear foreign key (footwear_id) references footwear (id) on delete restrict on update restrict;
create index ix_fit_footwear_footwear on fit_footwear (footwear_id);

alter table gender_footwear add constraint fk_gender_footwear_gender foreign key (gender_id) references gender (id) on delete restrict on update restrict;
create index ix_gender_footwear_gender on gender_footwear (gender_id);

alter table gender_footwear add constraint fk_gender_footwear_footwear foreign key (footwear_id) references footwear (id) on delete restrict on update restrict;
create index ix_gender_footwear_footwear on gender_footwear (footwear_id);

alter table order_item add constraint fk_order_item_order_id foreign key (order_id) references shop_order (id) on delete restrict on update restrict;
create index ix_order_item_order_id on order_item (order_id);

alter table order_item add constraint fk_order_item_basket_id foreign key (basket_id) references basket (id) on delete restrict on update restrict;
create index ix_order_item_basket_id on order_item (basket_id);

alter table order_item add constraint fk_order_item_fav_id foreign key (fav_id) references fav (id) on delete restrict on update restrict;
create index ix_order_item_fav_id on order_item (fav_id);

alter table order_item add constraint fk_order_item_footwear_id foreign key (footwear_id) references footwear (id) on delete restrict on update restrict;
create index ix_order_item_footwear_id on order_item (footwear_id);

alter table payment_footwear add constraint fk_payment_footwear_payment foreign key (payment_id) references payment (id) on delete restrict on update restrict;
create index ix_payment_footwear_payment on payment_footwear (payment_id);

alter table payment_footwear add constraint fk_payment_footwear_footwear foreign key (footwear_id) references footwear (id) on delete restrict on update restrict;
create index ix_payment_footwear_footwear on payment_footwear (footwear_id);

alter table shipping add constraint fk_shipping_shop_order_id foreign key (shop_order_id) references shop_order (id) on delete restrict on update restrict;

alter table shop_order add constraint fk_shop_order_customer_email foreign key (customer_email) references user (email) on delete restrict on update restrict;
create index ix_shop_order_customer_email on shop_order (customer_email);

alter table shop_order add constraint fk_shop_order_supervisor_email foreign key (supervisor_email) references user (email) on delete restrict on update restrict;
create index ix_shop_order_supervisor_email on shop_order (supervisor_email);

alter table shop_order_payment add constraint fk_shop_order_payment_shop_order foreign key (shop_order_id) references shop_order (id) on delete restrict on update restrict;
create index ix_shop_order_payment_shop_order on shop_order_payment (shop_order_id);

alter table shop_order_payment add constraint fk_shop_order_payment_payment foreign key (payment_id) references payment (id) on delete restrict on update restrict;
create index ix_shop_order_payment_payment on shop_order_payment (payment_id);

alter table size_footwear add constraint fk_size_footwear_size foreign key (size_id) references size (id) on delete restrict on update restrict;
create index ix_size_footwear_size on size_footwear (size_id);

alter table size_footwear add constraint fk_size_footwear_footwear foreign key (footwear_id) references footwear (id) on delete restrict on update restrict;
create index ix_size_footwear_footwear on size_footwear (footwear_id);

alter table true_fit_footwear add constraint fk_true_fit_footwear_true_fit foreign key (true_fit_id) references true_fit (id) on delete restrict on update restrict;
create index ix_true_fit_footwear_true_fit on true_fit_footwear (true_fit_id);

alter table true_fit_footwear add constraint fk_true_fit_footwear_footwear foreign key (footwear_id) references footwear (id) on delete restrict on update restrict;
create index ix_true_fit_footwear_footwear on true_fit_footwear (footwear_id);


# --- !Downs

alter table basket drop constraint if exists fk_basket_customer_email;

alter table category_footwear drop constraint if exists fk_category_footwear_category;
drop index if exists ix_category_footwear_category;

alter table category_footwear drop constraint if exists fk_category_footwear_footwear;
drop index if exists ix_category_footwear_footwear;

alter table colour_footwear drop constraint if exists fk_colour_footwear_colour;
drop index if exists ix_colour_footwear_colour;

alter table colour_footwear drop constraint if exists fk_colour_footwear_footwear;
drop index if exists ix_colour_footwear_footwear;

alter table fav drop constraint if exists fk_fav_customer_email;

alter table fit_footwear drop constraint if exists fk_fit_footwear_fit;
drop index if exists ix_fit_footwear_fit;

alter table fit_footwear drop constraint if exists fk_fit_footwear_footwear;
drop index if exists ix_fit_footwear_footwear;

alter table gender_footwear drop constraint if exists fk_gender_footwear_gender;
drop index if exists ix_gender_footwear_gender;

alter table gender_footwear drop constraint if exists fk_gender_footwear_footwear;
drop index if exists ix_gender_footwear_footwear;

alter table order_item drop constraint if exists fk_order_item_order_id;
drop index if exists ix_order_item_order_id;

alter table order_item drop constraint if exists fk_order_item_basket_id;
drop index if exists ix_order_item_basket_id;

alter table order_item drop constraint if exists fk_order_item_fav_id;
drop index if exists ix_order_item_fav_id;

alter table order_item drop constraint if exists fk_order_item_footwear_id;
drop index if exists ix_order_item_footwear_id;

alter table payment_footwear drop constraint if exists fk_payment_footwear_payment;
drop index if exists ix_payment_footwear_payment;

alter table payment_footwear drop constraint if exists fk_payment_footwear_footwear;
drop index if exists ix_payment_footwear_footwear;

alter table shipping drop constraint if exists fk_shipping_shop_order_id;

alter table shop_order drop constraint if exists fk_shop_order_customer_email;
drop index if exists ix_shop_order_customer_email;

alter table shop_order drop constraint if exists fk_shop_order_supervisor_email;
drop index if exists ix_shop_order_supervisor_email;

alter table shop_order_payment drop constraint if exists fk_shop_order_payment_shop_order;
drop index if exists ix_shop_order_payment_shop_order;

alter table shop_order_payment drop constraint if exists fk_shop_order_payment_payment;
drop index if exists ix_shop_order_payment_payment;

alter table size_footwear drop constraint if exists fk_size_footwear_size;
drop index if exists ix_size_footwear_size;

alter table size_footwear drop constraint if exists fk_size_footwear_footwear;
drop index if exists ix_size_footwear_footwear;

alter table true_fit_footwear drop constraint if exists fk_true_fit_footwear_true_fit;
drop index if exists ix_true_fit_footwear_true_fit;

alter table true_fit_footwear drop constraint if exists fk_true_fit_footwear_footwear;
drop index if exists ix_true_fit_footwear_footwear;

drop table if exists basket;

drop table if exists category;

drop table if exists category_footwear;

drop table if exists colour;

drop table if exists colour_footwear;

drop table if exists fav;

drop table if exists fit;

drop table if exists fit_footwear;

drop table if exists footwear;

drop table if exists gender;

drop table if exists gender_footwear;

drop table if exists order_item;

drop table if exists payment;

drop table if exists payment_footwear;

drop table if exists shipping;

drop table if exists shop_order;

drop table if exists shop_order_payment;

drop table if exists size;

drop table if exists size_footwear;

drop table if exists true_fit;

drop table if exists true_fit_footwear;

drop table if exists user;

