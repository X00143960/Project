function confirmDel() {
    return confirm("Are you sure?")
}
function bigImg(x) {
    x.style.height = "150px";
    x.style.width = "150px";
}

function normalImg(x) {
    x.style.height = "60px";
    x.style.width = "60px";
}

