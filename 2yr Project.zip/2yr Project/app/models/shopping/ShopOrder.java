package models.shopping;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

import java.util.Date;

import models.shoes.*;
import models.users.*;
import java.text.*;

@Entity
public class ShopOrder extends Model {

    @Id
    private Long id;
    
    private Calendar OrderDate;
    
    @ManyToMany(cascade = CascadeType.ALL)
    private List<Payment> payment;
    @OneToMany(mappedBy="order", cascade = CascadeType.ALL)
    private List<OrderItem> items;
    @OneToOne(mappedBy="shopOrder", cascade = CascadeType.ALL)
    private Shipping shipping;
    @ManyToOne
    private Customer customer;
    @ManyToOne
    private Supervisor supervisor;
    
    public void setPayment( List<Payment>payment){
        this.payment = payment;
    }
    public List<Payment> getPayment(){
        return payment;
    }
    
    public  ShopOrder() {
        OrderDate = Calendar.getInstance();
    }
    public double getOrderTotal() {
        
        double total = 0;
        
        for (OrderItem i: items) {
            total += i.getItemTotal();
        }
        return total;
    }
	
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
    public String dateString() {
        return dateFormat.format(OrderDate.getTime());
    }
    public static Finder<Long,ShopOrder> find = new Finder<Long,ShopOrder>(ShopOrder.class);


    public static List<ShopOrder> findAll() {
        return ShopOrder.find.all();
    }

    public Long getId() {
  
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Calendar getOrderDate() {
        return OrderDate;
    }

    public void setOrderDate(Calendar orderDate) {
        OrderDate = orderDate;
    }

    public List<OrderItem> getItems() {
        return items;
    }

    public void setItems(List<OrderItem> items) {
        this.items = items;
    }

    public Customer getCustomer() {
        return customer;
    }

   
    public void setSupervisor(Supervisor supervisor) {
        this.supervisor = supervisor;
    } 

    public Supervisor getSupervisor() {
        return supervisor;
    }

   
    public void setCustomer(Customer customer) {
        this.customer = customer;
    } 
    
    public static Map<String, String> options() {
        LinkedHashMap<String, String> options = new LinkedHashMap();

        for (ShopOrder s: ShopOrder.findAll()) {
            options.put(s.getId().toString(), s.dateString());
        }
        
        return options;

}
public Shipping getShipping() {
    return shipping;
}


public void setShipping(Shipping shipping) {
    // return Shipping.find.query().where()
    //                 .ilike("id",  + "%")
    //                 .orderBy("id asc")
    //                 .findList();
    this.shipping = shipping;
}
}