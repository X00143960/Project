package models.users;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;
import java.util.Calendar;
import models.shopping.*;

@Entity

@DiscriminatorValue("customer")

public class Customer extends User{
	
	private String street;
    private String county;
    private String postCode;
    private String creditCard;
    private String contactNum;
    @Temporal(TemporalType.DATE)
    private Calendar dob;

    @OneToOne(mappedBy="customer", cascade = CascadeType.ALL)
    private Basket basket;

    @OneToOne(mappedBy="customer", cascade = CascadeType.ALL)
    private Fav fav;


    @OneToMany(mappedBy="customer", cascade = CascadeType.ALL)
    private List<ShopOrder> orders;
	
	public Customer(String email, String role, String name, String password, String street, String county, String postCode, String creditCard, Calendar dob, String contactNum)
	{
		super(email, role, name, password);
        this.street = street;
        this.county = county;
        this.postCode = postCode;
		this.creditCard = creditCard;
	}

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }


    public String getContactNum(){
        return contactNum;
    }
     public void setContactNum(String contactNum){
     this.contactNum = contactNum;
     }
  
    public void setDob(Calendar dob){
        this.dob = dob;
    }
    public Calendar getDob(){
        return dob;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public String getCreditCard() {
        return creditCard;
    }

    public void setCreditCard(String creditCard) {
        this.creditCard = creditCard;
    }
    public Basket getBasket() {
        return basket;
    }

    public void setBasket(Basket basket) {
        this.basket = basket;
    }
    public Fav getFav() {
        return fav;
    }

    public void setFav(Fav fav) {
        this.fav = fav;
    }

    public List<ShopOrder> getOrders() {
        return orders;
    }

    public void setOrders(List<ShopOrder> orders) {
        this.orders = orders;
    }

}