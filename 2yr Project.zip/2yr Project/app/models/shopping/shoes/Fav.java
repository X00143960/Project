package models.shopping;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

import models.shoes.*;
import models.users.*;
import models.shoes.Footwear;


@Entity
public class Fav extends Model {

    @Id
    private Long id;
    
    @OneToMany(mappedBy = "fav", cascade = CascadeType.PERSIST)
    private List<OrderItem> basketItems;
    
    @OneToOne
    private Customer customer;


  
    public  Fav() {
    }
   
    public void addFootwear(Footwear f) {
        
        boolean itemFound = false;
       
        for (OrderItem i : basketItems) {
            if (i.getFootwear().getId() == f.getId()) {
                i.increaseQty();
                itemFound = true;
                break;
            }
        }
        if (itemFound == false) {
          
            OrderItem newItem = new OrderItem(f);
         
            basketItems.add(newItem);
        }
    }
    public void removeItem(OrderItem item) {


        for (Iterator<OrderItem> iter = basketItems.iterator(); iter.hasNext();) {
            OrderItem i = iter.next();
            if (i.getId().equals(item.getId()))
            {
               
                if (i.getQuantity() > 1 ) {
                    i.decreaseQty();
                }
              
                else {
                  
                    i.delete();
                 
                    iter.remove();
                    break;
                }             
            }
		}
    }
  
	
    public void removeAllItems() {
        for(OrderItem i: this.basketItems) {
            i.getFootwear().increaseStock(i.getQuantity());
            i.getFootwear().update();
            i.delete();
        }
        this.basketItems = null;
    }
    public static Finder<Long,Fav> find = new Finder<Long,Fav>(Fav.class);

    public static List<Fav> findAll() {
        return Fav.find.all();
    }
    public double getFavTotal() {
        
        double total = 0;
        
        for (OrderItem i: basketItems) {
            total += i.getItemTotal();
        }
        return total;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<OrderItem> getBasketItems() {
        return basketItems;
    }

    public void setBasketItems(List<OrderItem> basketItems) {
        this.basketItems = basketItems;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }


}
