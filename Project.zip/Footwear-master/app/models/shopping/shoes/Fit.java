
package models.shoes;


import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;






  
@Entity

public class Fit extends Model {

    @Id
    private Long id;
    @Constraints.Required
    private String fitOfShoe;

    @ManyToMany(cascade = CascadeType.ALL)
    private List<Footwear> footwear;




public Fit(){

}

public static List<Fit> findAll() {
    return Fit.find.query().where().orderBy("id asc").findList();
}
    public Fit(Long id, String fitOfShoe, List<Footwear> footwear) {
        this.id = id;
        this.fitOfShoe = fitOfShoe;
        this.footwear = footwear;
       
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFitOfShoe() {
        return fitOfShoe;
    }

    public void setFitOfShoe(String fitOfShoe) {
        this.fitOfShoe = fitOfShoe;
    }

 

    public void setFootwear( List<Footwear>footwear){
        this.footwear = footwear;
    }
    public List<Footwear> getFootwear(){
        return footwear;
    }
   

    public static Finder<Long, Fit> find = new Finder<Long, Fit>(Fit.class);


  





    public static Map<String,String> options() {
        LinkedHashMap<String,String> options = new LinkedHashMap<>();



        for(Fit f: Fit.findAll()) {
            options.put(Long.toString(f.getId()), f.getFitOfShoe());

        }
        return options;
    }
    
}

