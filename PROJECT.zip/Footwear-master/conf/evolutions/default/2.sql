


# --- !Ups

delete from category_footwear;
delete from size_footwear;
delete from gender_footwear;
delete from colour_footwear;
delete from fit_footwear;
delete from payment_footwear;
delete from footwear;
delete from category;
delete from Size;
delete from gender;
delete from colour;
delete from fit;
delete from payment;

insert into category (id,name) values ( 1,'Heels' );
insert into category (id,name) values ( 2,'Casual' );
insert into category (id,name) values ( 3,'Converse' );
insert into category (id,name) values ( 4,'Party' );
insert into category (id,name) values ( 5,'Leather' );
insert into category (id,name) values ( 6,'Spring/Summer' );
insert into category (id,name) values ( 7,'Autumn/Winter' ); 
insert into category (id,name) values ( 8,'Sandals' );
insert into category (id,name) values ( 9,'Mens' ); 
insert into category (id,name) values ( 10,'Womens' ); 


insert into size (id,size_of_shoe) values ( 1,4 );
insert into size (id,size_of_shoe) values ( 2,4.5 );
insert into size (id,size_of_shoe) values ( 3,5 );
insert into size (id,size_of_shoe) values ( 4,5.5);
insert into size (id,size_of_shoe) values ( 5,6 );
insert into size (id,size_of_shoe) values ( 6,6.5 );
insert into size (id,size_of_shoe) values ( 7,7 ); 
insert into size (id,size_of_shoe) values ( 8,7.5 ); 
insert into size (id,size_of_shoe) values ( 9,8 ); 
insert into size (id,size_of_shoe) values ( 10,8.5 );
insert into size (id,size_of_shoe) values ( 11,9);
insert into size (id,size_of_shoe) values ( 12,9.5);
insert into size (id,size_of_shoe) values ( 13,10 );
insert into size (id,size_of_shoe) values ( 15,11 );
insert into size (id,size_of_shoe) values ( 16,12);
insert into size (id,size_of_shoe) values ( 17,13 );
insert into size (id,size_of_shoe) values ( 18,14 );
 
 
insert into gender (id,  gender_v ) values ( 1,'f');
insert into gender (id,  gender_v) values (2,'m');
insert into gender (id,   gender_v ) values (3,'neutral');
insert into gender(id,  gender_v) values (4,'other');




insert into colour (id,  colour_of_shoe ) values ( 1,'Green');
insert into colour (id,  colour_of_shoe) values (2,'Yellow');
insert into colour (id,   colour_of_shoe) values (3,'neutral');
insert into colour(id,  colour_of_shoe) values (4,'Multi-Coloured');
insert into colour(id,  colour_of_shoe) values (5,'Blue');
insert into colour(id,  colour_of_shoe) values (6,'Black');
insert into colour(id,  colour_of_shoe) values (7,'Navy');
insert into colour(id,  colour_of_shoe) values (8,'Pink');
insert into colour(id,  colour_of_shoe) values (9,'Purple');
insert into colour(id,  colour_of_shoe) values (10,'Brown');
insert into colour(id,  colour_of_shoe) values (11,'Tan');
insert into colour(id,  colour_of_shoe) values (12,'Red');


insert into fit(id,  fit_of_shoe  ) values ( 1,'Wide');
insert into fit (id,  fit_of_shoe) values (2,'Narrow');
insert into fit (id,   fit_of_shoe) values (3,'Standard');
insert into fit(id,  fit_of_shoe) values (4,'Extra Small');
insert into fit(id,  fit_of_shoe) values (5,'Extra Large');

insert into payment (id, c_name ,credit_card_num , ccv, expiry_date   ) values(1,'Aoife Bergin', '1234567897', '817', '2011-01-01');
insert into payment (id, c_name ,credit_card_num , ccv, expiry_date   ) values(2,'Rachel Byrne', '1222567897', '827', '2014-01-01');
insert into payment (id, c_name ,credit_card_num , ccv, expiry_date   ) values(3,'Jordon Davy', '12327797', '816', '2011-01-01');
insert into payment (id, c_name ,credit_card_num , ccv, expiry_date   ) values(4,'Lara Lagio', '12345647873', '337', '2011-02-01');
  
insert into footwear (id,name,description,stock,price ) values ( 1,'Heel','Glamour',100,99.00);
insert into footwear (id,name,description,stock,price) values ( 2,'Dubarrys','Leather shoe',88,120.00);
insert into footwear (id,name,description,stock,price ) values ( 3,'Suede pom pom','pom pom shoe',577,300.00);
insert into footwear (id,name,description,stock,price) values ( 4,'Converse','High top',45,99.00);
insert into footwear (id,name,description,stock,price) values ( 5,'Converse','Low Top',5,56.00 );
insert into footwear (id,name,description,stock,price) values ( 6,'Vans','chunky',12,8900);
insert into footwear (id,name,description,stock,price ) values ( 7,'Christan Loubutin','red sole',50,699.00 );
insert into footwear (id,name,description,stock,price) values ( 8,'Lara','disney',45,40.00);
insert into footwear (id,name,description,stock,price) values ( 9,'wedges','4inch',5,79.00 );
insert into footwear (id,name,description,stock,price) values ( 10,'Jordan','air max',10,79.00);
insert into footwear (id,name,description,stock,price ) values ( 11,'Steven','converse',6,25.00);
insert into footwear (id,name,description,stock,price ) values ( 12,'flat leather','shiny',50,29.00 );
 
insert into category_footwear (category_id,footwear_id) values (10,1);
insert into category_footwear (category_id,footwear_id) values (5,2);
insert into category_footwear (category_id,footwear_id) values (1,12);
insert into category_footwear (category_id,footwear_id) values (3,4);
insert into category_footwear (category_id,footwear_id) values (10,5);
insert into category_footwear (category_id,footwear_id) values (8,6);
insert into category_footwear (category_id,footwear_id) values (6,7);
insert into category_footwear (category_id,footwear_id) values (10,8);  
insert into category_footwear (category_id,footwear_id) values (3,9);
insert into category_footwear (category_id,footwear_id) values (9,10);
insert into category_footwear (category_id,footwear_id) values (9,11);
insert into category_footwear (category_id,footwear_id) values (2,12);
insert into category_footwear (category_id,footwear_id) values (5,7);
insert into category_footwear (category_id,footwear_id) values (3,8);
insert into category_footwear (category_id,footwear_id) values (3,3); 

insert into size_footwear (size_id, footwear_id) values (5,1);
insert into size_footwear (size_id, footwear_id) values (5,2);
insert into size_footwear (size_id, footwear_id) values (4,3);
insert into size_footwear (size_id, footwear_id) values (3,4);
insert into size_footwear (size_id, footwear_id) values (3,5);
insert into size_footwear (size_id, footwear_id) values (8,6);
insert into size_footwear (size_id, footwear_id) values (6,7);
insert into size_footwear (size_id, footwear_id) values (7,8);
insert into size_footwear (size_id, footwear_id) values (3,9);
insert into size_footwear (size_id, footwear_id) values (5,10);
insert into size_footwear (size_id, footwear_id) values (4,11);
insert into size_footwear (size_id, footwear_id) values (2,12);
insert into size_footwear (size_id, footwear_id) values (5,7);
insert into size_footwear (size_id, footwear_id) values (3,8);
insert into size_footwear (size_id, footwear_id) values (3,3);

insert into gender_footwear(gender_id, footwear_id) values(1,1);
insert into gender_footwear(gender_id, footwear_id) values(2,2);
insert into gender_footwear(gender_id, footwear_id) values(3,3);
insert into gender_footwear(gender_id, footwear_id) values(4,4);
insert into gender_footwear(gender_id, footwear_id) values(4,5);
insert into gender_footwear(gender_id, footwear_id) values(4,6);
insert into gender_footwear(gender_id, footwear_id) values(4,7);
insert into gender_footwear(gender_id, footwear_id) values(4,8);
insert into gender_footwear(gender_id, footwear_id) values(4,9);
insert into gender_footwear(gender_id, footwear_id) values(4,10);
insert into gender_footwear(gender_id, footwear_id) values(4,11);
insert into gender_footwear(gender_id, footwear_id) values(4,12);

insert into colour_footwear(colour_id, footwear_id) values(1,1);
insert into colour_footwear(colour_id, footwear_id) values(2,2);
insert into colour_footwear(colour_id, footwear_id) values(3,3);
insert into colour_footwear(colour_id, footwear_id) values(4,4);
insert into colour_footwear(colour_id, footwear_id) values(4,5);
insert into colour_footwear(colour_id, footwear_id) values(5,6);
insert into colour_footwear(colour_id, footwear_id) values(7,7);
insert into colour_footwear(colour_id, footwear_id) values(6,8);
insert into colour_footwear(colour_id, footwear_id) values(9,9);
insert into colour_footwear(colour_id, footwear_id) values(4,10);
insert into colour_footwear(colour_id, footwear_id) values(5,11);
insert into colour_footwear(colour_id, footwear_id) values(12,12);



insert into fit_footwear( fit_id , footwear_id) values(1,1);

insert into fit_footwear( fit_id , footwear_id) values(2,2);

insert into fit_footwear( fit_id , footwear_id) values(3,3);

insert into fit_footwear( fit_id , footwear_id) values(4,4);

insert into fit_footwear( fit_id , footwear_id) values(5,5);

insert into fit_footwear( fit_id , footwear_id) values(1,6);

insert into fit_footwear (fit_id , footwear_id) values(2,7);

insert into fit_footwear( fit_id , footwear_id) values(3,8);

insert into fit_footwear( fit_id , footwear_id) values(4,9);

insert into fit_footwear( fit_id , footwear_id) values(5,10);

insert into fit_footwear( fit_id , footwear_id) values(1,11);

insert into fit_footwear( fit_id , footwear_id) values(2,12);





insert into payment_footwear( payment_id , footwear_id) values(1,1);

insert into payment_footwear( payment_id , footwear_id) values(2,2);

insert into payment_footwear( payment_id , footwear_id) values(3,3);

insert into payment_footwear( payment_id , footwear_id) values(4,4);










