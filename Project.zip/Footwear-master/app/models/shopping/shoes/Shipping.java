package models.shoes;

import models.shopping.*;

import java.util.*;
import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Id;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

import java.util.Date;

import models.shoes.*;
import models.users.*;
import java.text.*;
import play.data.format.*;
@Entity
public class Shipping extends Model {
    @Id
private Long id;
    private Double shippingFee;
  @Temporal(TemporalType.DATE)   
   private Date shipDate;
   
    private String shippAddress;
private String cName;

    @OneToOne
    private ShopOrder shopOrder;
    public Shipping (){

    }
    public Shipping(Double shippingFee, Date shipDate, String shippAddress, Long id, String cName) {

        this.shippingFee = shippingFee;
        this.shipDate = shipDate;
        this.shippAddress = shippAddress;
        this.id = id;
        this.cName = cName;
    }

    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");

    public Double getShippingFee() {
        return shippingFee;
    }

    public void setShippingFee(Double shippingFee) {
        this.shippingFee = shippingFee;
    }

    public Date getShipDate() {
return shipDate;
    }
    public void setShipDate(Date shipDate) {
        this.shipDate = shipDate;
    }
    public String getShipDateString() {
        if(shipDate == null) {
            return "No Date Availible";
        }
        String s = new SimpleDateFormat("dd-MMM-yyyy").format(shipDate.getTime());
        return s;
    }
    public String getShippAddress() {
        return shippAddress;
    }

    public void setShippAddress(String shippAddress) {
        this.shippAddress = shippAddress;
    }
    
    
    public static Finder<Long,Shipping> find = new Finder<Long,Shipping>(Shipping.class);


    public static List<Shipping> findAll() {
        return Shipping.find.all();
    }

    public ShopOrder getShopOrder() {
        return shopOrder;
    }

    public void setShopOrder(ShopOrder shopOrder) {
        this.shopOrder = shopOrder;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getCName() {
        return cName;
    }

    public void setCName(String cName) {
        this.cName = cName;
    }
}