# --- !Ups
delete from user;

insert into user (email,name,password,role, num_returns) values ( 'admin@products.com', 'Alice Admin', 'password', 'admin', 0);

insert into user (email,name,password,role, num_returns) values ( 'supervisor@products.com', 'Sally Supervisor', 'password', 'supervisor', 0);

insert into user (email,name,password,role, num_returns) values ( 'customer@products.com', 'Charlie Customer', 'password', 'customer', 0);

