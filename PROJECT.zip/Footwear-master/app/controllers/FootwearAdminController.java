package controllers;

import controllers.security.*;

import play.mvc.*;
import play.api.Environment;
import play.data.*;
import play.db.ebean.Transactional;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;


import models.users.*;
import models.shoes.*;
import views.html.*;

import play.mvc.Http.*;
import play.mvc.Http.MultipartFormData.FilePart;
import java.io.File;

 import org.im4java.core.ConvertCmd;
import org.im4java.core.IMOperation;

@Security.Authenticated(Secured.class)

@With(CheckIfAdmin.class)


public class FootwearAdminController extends Controller {

 
    private FormFactory formFactory;
    private Environment e;
    
    @Inject
    public FootwearAdminController(FormFactory f,Environment env) {
        this.formFactory = f;
        this.e = env;
    }
    
	private User getCurrentUser() {
		User u = User.getUserById(session().get("email"));
		return u;
	}
   
   
    @Transactional
    public Result listFootwear(Long cat,String filter) {
    
        List<Category> categories = Category.findAll();
		
        List<Footwear> shoes = new ArrayList<Footwear>();
    	
        List<Gender> genders = new ArrayList<Gender>();
        List<Size> sizes = new ArrayList<Size>();
        List<Colour> colours = new ArrayList<Colour>();
        List<Fit> fitSize = new ArrayList<Fit>();


        
        if (cat == 0) {
          
          shoes = Footwear.findAll();
          System.out.println("After findAll");
    }else {

 shoes = Category.find.ref(cat).getFootwear();
     }
    
       return ok(listFootwear.render(e,shoes, categories, genders,colours,fitSize, sizes,getCurrentUser(),cat,filter));
    }

    @Transactional
    public Result addFootwear() {
        Form<Footwear> addFootwearForm = formFactory.form(Footwear.class);
        return ok(addFootwear.render(addFootwearForm, getCurrentUser()));
    }
    @Transactional
    public Result addFootwearSubmit() {
        Footwear newFootwear;
        String saveImageMsg;
        Form<Footwear> newFootwearForm = formFactory.form(Footwear.class).bindFromRequest();

        if (newFootwearForm.hasErrors()) {
            return badRequest(addFootwear.render(newFootwearForm, 
            getCurrentUser()));
        }
        else {
             newFootwear = newFootwearForm.get();

        
                newFootwear.save();
                   
                    for (Long cat : newFootwear.getCatSelect()) {
                        newFootwear.categories.add(Category.find.byId(cat));
                       
                          
                    }            
                    
                newFootwear.update();
        }
         MultipartFormData data = request().body().asMultipartFormData();
         FilePart<File> image = data.getFile("upload");

         saveImageMsg = saveFile(newFootwear.getId(), image);

         flash("success", "Footwear " + newFootwear.getName() + " has been created/updated " + saveImageMsg);

        return redirect(routes.ProductController.index());
    }
    
   
    @Transactional
    public Result deleteFootwear(Long id) {
        Footwear.find.ref(id).delete();

        flash("success", "shoes have been deleted");
        
        return redirect(routes.ProductController.index());
    }


    @Transactional
    public Result updateFootwear(Long id) {
        Footwear f;
        Form<Footwear> footwearForm;

        try {
            f = Footwear.find.byId(id);
            footwearForm = formFactory.form(Footwear.class).fill(f);
        } 
        catch (Exception ex) {
            return badRequest("error");
        }
        return ok(updateFootwear.render(id, footwearForm,getCurrentUser()));
    }

    @Transactional
   public Result updateFootwearSubmit(Long id) {
    String saveImageMsg;
        
            
                Form<Footwear> updateFootwearForm = formFactory.form(Footwear.class).bindFromRequest();
    
                if (updateFootwearForm.hasErrors()) {
                 
                    return badRequest(updateFootwear.render(id,updateFootwearForm, getCurrentUser()));
                } else {
                  
                    Footwear f = updateFootwearForm.get();
                    f.setId(id);                    
                    
             
                    List<Category> newCats = new ArrayList<Category>();
                    for (Long cat : f.getCatSelect()) {
                        newCats.add(Category.find.byId(cat));
                    }
                    f.categories = newCats;
                  
                    f.update();
        
                    MultipartFormData data = request().body().asMultipartFormData();
                    FilePart<File> image = data.getFile("upload");
        
                 saveImageMsg = saveFile(f.getId(), image);
        
                 flash("success", "Shoes " + f.getName() + " have been created/updated " + saveImageMsg);
                    
                    // Redirect to the admin home
                    return redirect(routes.ProductController.index());
                }
            }

            

    public String saveFile(Long id, FilePart<File> uploaded) {
     
    if (uploaded != null) {
        
           String mimeType = uploaded.getContentType(); 
            if (mimeType.startsWith("image/")) {
               
               String fileName = uploaded.getFilename();                
             
                File file = uploaded.getFile();
                
                IMOperation op = new IMOperation();
            
                op.addImage(file.getAbsolutePath());
                
                op.resize(300, 200);
           
                op.addImage("public/images/footwearImages/" + id + ".jpg");
            
                 IMOperation thumb = new IMOperation();
               thumb.addImage(file.getAbsolutePath());
               thumb.resize(60);
                thumb.addImage("public/images/footwearImages/thumbnails/" + id + ".jpg");
            
                File dir = new File("public/images/footwearImages/thumbnails/");
                if (!dir.exists()) {
                    dir.mkdirs();
                }
            
               ConvertCmd cmd = new ConvertCmd();
            try {
                    cmd.run(op);
                    cmd.run(thumb);
                } catch(Exception e) {
                   e.printStackTrace();
                }
                return " and image saved";
        }
    }
        return "/ no file";
     }
     public String saveFileOld(Long id, FilePart<File> uploaded) {
  
        String mimeType = uploaded.getContentType(); 
       if (uploaded != null) {
         
           if (mimeType.startsWith("image/")) {
           
                String fileName = uploaded.getFilename();      
               String extension = "";
                int i = fileName.lastIndexOf('.');
               if (i >= 0) {
                    extension = fileName.substring(i+1);
                }
        
             File file = uploaded.getFile();
               
                File dir = new File("public/images/footwearImages");
                if (!dir.exists()) {
                 dir.mkdirs();
             }
              
                if(file.renameTo(new File("public/images/footwearImages/", id + "." + extension))) {
                    return "/ file uploaded";
                } else {
             return "/ file upload failed";
                }
             }
        }
         return "/ no file";

   
    }
    @With(CheckIfAdmin.class)
    @Transactional
public Result addColour() {
    Form<Colour> addColourForm = formFactory.form(Colour.class);
    return ok(addColour.render(addColourForm, getCurrentUser()));
}
@Transactional
@With(CheckIfAdmin.class)
public Result addColourSubmit() {
    Colour newColour;
    String saveImageMsg;
    Form<Colour> newColourForm = formFactory.form(Colour.class).bindFromRequest();

    if (newColourForm.hasErrors()) {
        return badRequest(addColour.render(newColourForm, 
        getCurrentUser()));
    }
    else {
         newColour = newColourForm.get();

    
            newColour.save();
               
                // for (Long cat : newColour.getCatSelect()) {
                //     newFootwear.categories.add(Category.find.byId(cat));
                   
                      
                // }            
                
            newColour.update();
    }
     MultipartFormData data = request().body().asMultipartFormData();
     FilePart<File> image = data.getFile("upload");

     saveImageMsg = saveFile(newColour.getId(), image);

     flash("success", "Colour " + newColour.getColourOfShoe() + " has been created/updated " + saveImageMsg);

    return redirect(routes.ProductController.index());
}


@Transactional
public Result deleteColour(Long id) {
    Colour.find.ref(id).delete();

    flash("success", "colour deleted");
    
    return redirect(routes.ProductController.index());
}


@Transactional
public Result updateColour(Long id) {
    Colour c;
    Form<Colour> colourForm;

    try {
        c = Colour.find.byId(id);
        colourForm = formFactory.form(Colour.class).fill(c);
    } 
    catch (Exception ex) {
        return badRequest("error");
    }
    return ok(updateColour.render(id, colourForm,getCurrentUser()));
}

@Transactional
public Result updateColourSubmit(Long id) {
String saveImageMsg;
    
        
            Form<Colour> updateColourForm = formFactory.form(Colour.class).bindFromRequest();

            if (updateColourForm.hasErrors()) {
             
                return badRequest(updateColour.render(id,updateColourForm, getCurrentUser()));
            } else {
              
             Colour c = updateColourForm.get();
                c.setId(id);                    
                
         
                // List<Category> newCats = new ArrayList<Category>();
                // for (Long cat : f.getCatSelect()) {
                //     newCats.add(Category.find.byId(cat));
                // }
                // f.categories = newCats;
              
                c.update();
    
                MultipartFormData data = request().body().asMultipartFormData();
                FilePart<File> image = data.getFile("upload");
    
             saveImageMsg = saveFile(c.getId(), image);
    
             flash("success", "Colour " + c.getColourOfShoe() + " has been created/updated " + saveImageMsg);
                
                // Redirect to the admin home
                return redirect(routes.ProductController.index());
            }
        }

     


public Result addCustomer()
{

    Form<Customer> customerForm = formFactory.form(Customer.class);
    return ok(addCustomer.render(customerForm));
}

public Result addCustomerSubmit()
{
    Form<Customer> newCustomerForm = formFactory.form(Customer.class).bindFromRequest();
    
    if (newCustomerForm.hasErrors())
    {
        return badRequest(addCustomer.render(newCustomerForm));
    }
    else
    {
        Customer newCustomer = newCustomerForm.get();

        if(newCustomer.getId() == null)
        {
            newCustomer.save();
        }
        else if(newCustomer.getId() != null)
        {
            newCustomer.update();
        }

        flash("success", "Account "+ newCustomer.getName() + " was added");

        return redirect(controllers.routes.HomeController.index());
    }
}

/*
public Result deleteAccount(Long id)
{
    Customer.find.ref(id).delete();

    flash("success", "Account has been deleted");

    return redirect(routes.???.index());
}
*/

/*@Transactional
public Result updateCustomer(Long id)
{
    Customer c;
    Form<Customer> customerForm;

    try
    {
        c = Customer.find.byId(id);

        customerForm = formFactory.form(Customer.class).fill(p);
    }
    catch (Exception ex)
    {
        return badRequest("error");
    }

    return ok(addCUstomer.render(customerForm));
}*/

}

    

