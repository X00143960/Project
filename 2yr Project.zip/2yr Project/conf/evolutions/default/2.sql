# --- !Ups

delete from category_footwear;
delete from size_footwear;
delete from gender_footwear;
delete from colour_footwear;
delete from fit_footwear;
delete from payment_footwear;
delete from footwear;
delete from category;
delete from Size;
delete from gender;
delete from colour;
delete from fit;
delete from payment;
delete from shipping;
delete from true_fit;


insert into category (id,name) values ( 1,'Heels' );
insert into category (id,name) values ( 2,'Casual' );
insert into category (id,name) values ( 3,'Converse' );
insert into category (id,name) values ( 4,'Party' );
insert into category (id,name) values ( 5,'Leather' );
insert into category (id,name) values ( 6,'Spring/Summer' );
insert into category (id,name) values ( 7,'Autumn/Winter' ); 
insert into category (id,name) values ( 8,'Sandals' );
insert into category (id,name) values ( 9,'Mens' ); 
insert into category (id,name) values ( 10,'Womens' ); 


insert into size (id,size_of_shoe) values ( 1,4 );
insert into size (id,size_of_shoe) values ( 2,4.5 );
insert into size (id,size_of_shoe) values ( 3,5 );
insert into size (id,size_of_shoe) values ( 4,5.5);
insert into size (id,size_of_shoe) values ( 5,6 );
insert into size (id,size_of_shoe) values ( 6,6.5 );
insert into size (id,size_of_shoe) values ( 7,7 ); 
insert into size (id,size_of_shoe) values ( 8,7.5 ); 
insert into size (id,size_of_shoe) values ( 9,8 ); 
insert into size (id,size_of_shoe) values ( 10,8.5 );
insert into size (id,size_of_shoe) values ( 11,9);
insert into size (id,size_of_shoe) values ( 12,9.5);
insert into size (id,size_of_shoe) values ( 13,10 );
insert into size (id,size_of_shoe) values ( 15,11 );
insert into size (id,size_of_shoe) values ( 16,12);
insert into size (id,size_of_shoe) values ( 17,13 );
insert into size (id,size_of_shoe) values ( 18,14 );
 
 
insert into gender (id,  gender_v ) values ( 1,'f');
insert into gender (id,  gender_v) values (2,'m');
insert into gender (id,   gender_v ) values (3,'neutral');
insert into gender(id,  gender_v) values (4,'other');



insert into true_fit(size, new_shoe, old_shoe) values (5,'sports','sports');
insert into true_fit(size,  new_shoe, old_shoe) values (7,'workwear','workwear');
insert into true_fit(size, new_shoe, old_shoe) values (6,'heels','heels');
insert into true_fit(size, new_shoe, old_shoe) values (8,'boots','boots');
