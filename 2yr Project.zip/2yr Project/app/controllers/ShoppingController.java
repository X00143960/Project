package controllers;
import models.shopping.Payment;
import play.mvc.*;
import play.data.*;
import javax.inject.Inject;
import io.ebean.*;
import java.util.*;
import java.time.*;
import views.html.*;
import play.db.ebean.Transactional;
import play.api.Environment;
import models.users.*;
import models.shoes.*;
import models.shopping.*;
import controllers.security.*;
import play.mvc.Http.MultipartFormData.FilePart;
import java.io.File;
import controllers.security.*;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;



import models.users.*;
import models.shoes.*;
import views.html.*;

import play.mvc.Http.*;
import play.mvc.Http.MultipartFormData.FilePart;
import java.io.File;

 import org.im4java.core.ConvertCmd;
import org.im4java.core.IMOperation;





@Security.Authenticated(Secured.class)




public class ShoppingController extends Controller {

    private FormFactory formFactory;
    private Environment env;

    @Inject 
    public ShoppingController(Environment e, FormFactory f){
        this.env = e;
        this.formFactory = f;
    }

       
    
    private Customer getCurrentUser() {
        return (Customer)User.getUserById(session().get("email"));
    }
    
    private Supervisor getCurrentUserS() {
        return (Supervisor)User.getUserById(session().get("email"));
    }
  
    @Transactional
    @With(CheckIfCustomer.class)
    public Result showBasket() {
        if(basket.render(getCurrentUser())== null) {
            System.out.println("No items in basket yet");
        }else {
            return ok(basket.render(getCurrentUser()));
        
        
    }
    return redirect(routes.ShoppingController.showBasket());
    }
    
    @Transactional
    @With(CheckIfCustomer.class)
    public Result addToBasket(Long id) {
        
        // Find the product
       Footwear f = Footwear.find.byId(id);
        
        // Get basket for logged in customer
        Customer customer = (Customer)User.getUserById(session().get("email"));
        
        // Check if item in basket
        if (customer.getBasket() == null) {
            // If no basket, create one
            customer.setBasket(new Basket());
            customer.getBasket().setCustomer(customer);
            customer.update();
        }
        // Add product to the basket and save
        if(f.getStock() == 0){
            flash("error", "out of stock!");
            return redirect(routes.ProductController.listFootwear(0,""));
        }
        else {

            customer.getBasket().addFootwear(f);
        customer.update();
        f.decrementStock();
        f.update();
        // Show the basket contents     
        return ok(basket.render(customer));
        }
        
    }
        
    public Result viewOrders(){
        Customer currUser = getCurrentUser();
   List<ShopOrder>orders = Ebean.find(ShopOrder.class)
   .where().eq("customer",currUser)
   .findList();
   return ok(viewOrders.render(currUser,orders));
 } 
 
 public Result viewOneOrder(){
    Customer currUser = getCurrentUser();
List<ShopOrder>orders = Ebean.find(ShopOrder.class)
.where().eq("customer",currUser)
.findList();
return ok(viewOrders.render(currUser,orders));
} 
//  public Result viewRefunds(){
//     Supervisor currUserS = getCurrentUserS();
//     List<ShopOrder>orders = Ebean.find(ShopOrder.class)
//     .where().eq("supervisor",currUserS)
//     .findList();

// return ok(viewRefunds.render(currUserS,orders));
// } 
    
    // Add an item to the basket
    @Transactional
    @With(CheckIfCustomer.class)
    public Result addOne(Long itemId, Long fid) {
        
        // Get the order item
        OrderItem item = OrderItem.find.byId(itemId);
        // Increment quantity
        Footwear f = Footwear.find.byId(fid);
      
        if(f.decrementStock()){
            // Increment quantity
     item.increaseQty();
// Save
       item.update();
         f.update();
} else{
    flash("error", "Sorry, no more of these products left");
}


// Show updated basket
return redirect(routes.ShoppingController.showBasket());
}

    @Transactional
    @With(CheckIfCustomer.class)
    public Result removeOne(Long itemId) {
        
        // Get the order item
        OrderItem item = OrderItem.find.byId(itemId);
        // Get user
        Customer c = getCurrentUser();
        // Call basket remove item method
        c.getBasket().removeItem(item);
        c.getBasket().update();
        // back to basket
        item.getFootwear().incrementStock(1);
        item.getFootwear().update();
      
        return ok(basket.render(c));
    }

  
     // Empty Basket
     @Transactional
     @With(CheckIfCustomer.class)
     public Result emptyBasket() {
         
         Customer c = getCurrentUser();
         c.getBasket().removeAllItems();
         c.getBasket().update();
         
         return ok(basket.render(c));
     }

     @Transactional
     @With(CheckIfCustomer.class)
     public Result placeOrder() {

        
         Customer c = getCurrentUser();
         Shipping s = new Shipping();
         s.save();
         ShopOrder order = new ShopOrder();
         order.getShipping();
         order.setShipping(s);
         order.setCustomer(c);
         order.setItems(c.getBasket().getBasketItems());
         order.save();
         order.update();
         for (OrderItem i: order.getItems()) {
        
             i.setOrder(order);
             i.setBasket(null);
             i.update();
         }
         order.update();
         c.getBasket().setBasketItems(null);
         c.getBasket().update();
         c.update();
         return ok(confirmOrder.render(c, order));
     }
     
    
    @Transactional
    public Result viewOrder(long id) {
        ShopOrder order = ShopOrder.find.byId(id);
        return ok(confirmOrder.render(getCurrentUser(),order));
    }
    @With(CheckIfCustomer.class)
    public Result returns(Long id){
     
        ShopOrder order = ShopOrder.find.byId(id);
       
        return ok(returns.render(getCurrentUser(),order));
    }

   


    @With(CheckIfCustomer.class)
    public Result cancelOrder(long id) {
        ShopOrder order = ShopOrder.find.byId(id);

        if (order == null) {
            flash("success", "Order Order not found");
            return redirect(routes.ShoppingController.viewOrders());
        }

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime orderTime = LocalDateTime.ofInstant(order.getOrderDate().toInstant(), ZoneId.systemDefault());
        

        if (orderTime.getYear() == now.getYear()) {
            if (orderTime.getMonthValue() == now.getMonthValue()) {
                if (orderTime.getDayOfYear() == now.getDayOfYear()) {
                    if ((now.getHour() - orderTime.getHour()) <= 1) {
                        order.delete();
                        flash("success", "Order Cancelled");
                        return redirect(routes.ShoppingController.viewOrders());
                    }  
                }
            }
        }

        flash("success", "Order is too late to be Cancelled");
        return redirect(routes.ShoppingController.viewOrders());
    }

    // @Transactional
//     @With(CheckIfCustomer.class)
//     public Result paymentLanding() {

      
        
//         return redirect(routes.ShoppingController.addPayment());
//  }
    @With(CheckIfCustomer.class)
    public Result addPayment(Long id) {
        String p;
        if (id == 0) {
             p = "";
        } else {
            p = Payment.find.ref(id).getCreditCardNum();
        }

      
      Form<Payment> addPaymentForm = formFactory.form(Payment.class);
        return ok(addPayment.render(addPaymentForm, 
        getCurrentUser(),p,id)); 
 }
    // @Transactional
    @With(CheckIfCustomer.class)
    public Result addPaymentSubmit(String ccNum, Long id) {
        Payment newPayment;
     
        Form<Payment> newPaymentForm = formFactory.form(Payment.class).bindFromRequest();
    
        if (newPaymentForm.hasErrors() || !Payment.checkNum( ccNum)) {
            return badRequest(addPayment.render(newPaymentForm, 
            getCurrentUser(),Payment.find.ref(id).getCreditCardNum(),id));
           // String.valueOf(newPaymentForm.apply(creditCardNum
        }
        else {
            Ebean.beginTransaction();
            try{
             newPayment = newPaymentForm.get();
    
        
                newPayment.save();
                newPayment.update();
                Ebean.commitTransaction();      
            }    
                
                finally{
                    Ebean.endTransaction();
                }
        }
       
    
         flash("success", "Payment Successful");
    
        return redirect(routes.ShoppingController.thankYou());
    }

    public Result returnpolicy(){
        return ok(returnspolicy.render(User.getUserById(session().get("email"))));
    }

    @Transactional
    public Result addShipping() {
        Form<Shipping> addShippingForm = formFactory.form(Shipping.class);
        return ok(addshipping.render(addShippingForm, getCurrentUser()));
    }
    @Transactional
    public Result addShippingSubmit() {
        Shipping newShipping;
        Form<Shipping> newShippingForm = formFactory.form(Shipping.class).bindFromRequest();

        if (newShippingForm.hasErrors()) {
            return badRequest(addshipping.render(newShippingForm, 
            getCurrentUser()));
        }
        else {
            newShipping = newShippingForm.get();        
            newShipping.save();
            flash("success", "Order " + newShipping.getId() + " has been created");
            return redirect(routes.ShoppingController.addPayment(0));            
        }
        // return null;            
    }




    public Result thankYou(){
        
        Customer currUser = getCurrentUser();
        List<ShopOrder> orders = currUser.getOrders();
        return ok(thankyou.render(currUser,orders));

    }

    @Transactional
    @With(CheckIfCustomer.class)
    public Result addToFav(Long id) {
        
        // Find the product
       Footwear f = Footwear.find.byId(id);
        
        // Get basket for logged in customer
        Customer customer = (Customer)User.getUserById(session().get("email"));
        
        // Check if item in basket
        if (customer.getFav() == null) {
            // If no basket, create one
            customer.setFav(new Fav());
            customer.getFav().setCustomer(customer);
            customer.update();
        }
        // Add product to the basket and save
        if(f.getStock() == 0){
            flash("error", "out of stock!");
            return redirect(routes.ProductController.listFootwear(0,""));
        }
        else {

            customer.getFav().addFootwear(f);
        customer.update();
       
        f.update();
        // Show the basket contents     
        return ok(fav.render(customer));
        }
        
    }
        
    
    @Transactional
    @With(CheckIfCustomer.class)
    public Result showFav() {
        if(fav.render(getCurrentUser())== null) {
            System.out.println("No items in wishlist yet");
        }else {
            return ok(fav.render(getCurrentUser()));
        
        
    }
    return redirect(routes.ShoppingController.showFav());
    }
     
    @Transactional
    @With(CheckIfCustomer.class)
    public Result emptyFav() {
        
        Customer c = getCurrentUser();
        c.getFav().removeAllItems();
        c.getFav().update();
        
        return ok(fav.render(c));
    }
    @Transactional
public Result updateOrder(Long id) {
    ShopOrder o;
    Form<ShopOrder> OrderForm;

    try {
        o = ShopOrder.find.byId(id);
        OrderForm = formFactory.form(ShopOrder.class).fill(o);
        o.save();
    } 
    catch (Exception ex) {
        return badRequest("error");
    }
    return ok(updateOrder.render(id, OrderForm,getCurrentUser()));
}

@Transactional
public Result updateOrderSubmit(Long id) {

    
        
            Form<ShopOrder> updateOrderForm = formFactory.form(ShopOrder.class).bindFromRequest();

            if (updateOrderForm.hasErrors()) {
             
                return badRequest(updateOrder.render(id,updateOrderForm, getCurrentUser()));
            } else {
              
             ShopOrder o  = updateOrderForm.get();
                o.setId(id);                    
                
         
                // List<Category> newCats = new ArrayList<Category>();
                // for (Long cat : f.getCatSelect()) {
                //     newCats.add(Category.find.byId(cat));
                // }
                // f.categories = newCats;
              
                o.update();
    
            //     MultipartFormData data = request().body().asMultipartFormData();
            //     FilePart<File> image = data.getFile("upload");
    
            //  saveImageMsg = saveFile(c.getId(), image);
    
             flash("success", "Order  has been created/updated ");
                
                // Redirect to the admin home
                return redirect(routes.ProductController.index());
            }
        }

  


@Transactional
public Result deleteColour(Long id) {
    Colour.find.ref(id).delete();

    flash("success", "colour deleted");
    
    return redirect(routes.ProductController.index());
}

public Result addTrueFits(){
    Form<TrueFit> addTrueFitForm = formFactory.form(TrueFit.class);
return ok(addTrueFits.render(addTrueFitForm, getCurrentUser()));
}
@Transactional
public Result addTrueFit() {
    Form<TrueFit> addTrueFitForm = formFactory.form(TrueFit.class);
    return ok(addTrueFits.render(addTrueFitForm, getCurrentUser()));
}
@Transactional
public Result addTrueFitSubmit() {
    TrueFit newTrueFit;
   
    Form<TrueFit> addTrueFitForm = formFactory.form(TrueFit.class).bindFromRequest();

    if (addTrueFitForm.hasErrors()) {
        return badRequest(addTrueFits.render(addTrueFitForm, getCurrentUser()));
    
    }
    else {
        
      
         newTrueFit  = addTrueFitForm.get();
         newTrueFit.checkSize();
         newTrueFit.setSize(newTrueFit.checkSize());

            newTrueFit.save();
          
            newTrueFit.update();
    }
     
    flash("success", "your true fit for this shoe is: " + newTrueFit.getSize());
    return redirect(routes.ProductController.index());
}


}

