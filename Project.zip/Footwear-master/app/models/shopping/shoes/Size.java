package models.shoes;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class Size extends Model {
    @Id
    private Long id; 

 
    @Constraints.Required
    private Double sizeOfShoe;


    @ManyToMany(cascade = CascadeType.ALL)
    private List<Footwear> footwear = new ArrayList<>();


    public Size() {

    }

    public Size(Double sizeOfShoe,Long id,  List<Footwear> footwear) {
       this.sizeOfShoe = sizeOfShoe;
        this.footwear = footwear;
        this.id = id;
   
    }
    
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public void setSizeOfShoe(Double sizeOfShoe){

    this.sizeOfShoe = sizeOfShoe;
    }


    public Double getSizeOfShoe(){
       return sizeOfShoe;
    }

    public void setFootwear( List<Footwear>footwear){
        this.footwear = footwear;
    }
    public List<Footwear> getFootwear(){
        return footwear;
    }
    public static Finder<Long, Size> find = new Finder<Long, Size>(Size.class);

     public static List<Size> findAll() {
    return Size.find.query().where().orderBy("sizeOfShoe asc").findList();
      }
    public static Map<String, String> options() {

    LinkedHashMap<String, String> options = new LinkedHashMap();

    for (Size s: Size.findAll()) {
        options.put(s.getId().toString(), s.getSizeOfShoe().toString());
    }
    
    return options;


} }

